//
//  BRMEntryController.m
//  JournalObjC
//
//  Created by Bethany Morris on 5/4/20.
//  Copyright © 2020 Bethany M. All rights reserved.
//

#import "BRMEntryController.h"
#import "BRMEntry.h"

static NSString * const EntriesKey = @"entries";

@interface BRMEntryController ()

@property (nonatomic, strong) NSMutableArray *internalEntries;

@end

@implementation BRMEntryController

//MARK: - Singleton

+ (BRMEntryController *)sharedInstance
{
    static BRMEntryController *sharedInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedInstance = [BRMEntryController new];
        [sharedInstance loadFromPersistentStorage];
    });
    
    return sharedInstance;
}

// MARK: - Source of Truth

- (instancetype)init
{
    self = [super init];
    if (self) {
        _entries = [NSMutableArray array];
    }
    return self;
}

//MARK: - CRUD Methods

- (NSArray *)entries { return _entries; }

- (void) addEntry:(BRMEntry *)entry
{
    [_entries addObject:entry];
}

- (void) deleteEntry:(BRMEntry *)entry
{
    [_entries removeObject:entry];
}

// MARK: - Persistance Storage

- (void)saveToPersistentStorage
{
    NSMutableArray *entryDictionaries = [NSMutableArray new];
    
    for (BRMEntry *entry in self.entries) {
        [entryDictionaries addObject:entry.dictionaryRepresentation];
    }
    
    [[NSUserDefaults standardUserDefaults] setObject:entryDictionaries forKey:EntriesKey];
}

- (void)loadFromPersistentStorage
{
    NSArray *entryDictionaries = [[NSUserDefaults standardUserDefaults] objectForKey:EntriesKey];
    for (NSDictionary *dictionary in entryDictionaries) {
        BRMEntry *entry = [[BRMEntry alloc] initWithDictionary:dictionary];
        [self addEntry:entry];
    }
}


@end
