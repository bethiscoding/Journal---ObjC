//
//  BRMEntryController.h
//  JournalObjC
//
//  Created by Bethany Morris on 5/4/20.
//  Copyright © 2020 Bethany M. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BRMEntry.h"

NS_ASSUME_NONNULL_BEGIN

@interface BRMEntryController : NSObject

+ (BRMEntryController *)sharedInstance;

@property (nonatomic, strong) NSMutableArray *entries;

- (void) addEntry:(BRMEntry *)entry;
- (void) deleteEntry:(BRMEntry *)entry;

- (void) saveToPersistentStorage;
- (void) loadFromPersistentStorage;

@end

NS_ASSUME_NONNULL_END
