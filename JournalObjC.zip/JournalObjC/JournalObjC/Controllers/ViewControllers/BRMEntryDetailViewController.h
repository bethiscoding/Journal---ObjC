//
//  BRMEntryDetailViewController.h
//  JournalObjC
//
//  Created by Bethany Morris on 5/4/20.
//  Copyright © 2020 Bethany M. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BRMEntry.h"

NS_ASSUME_NONNULL_BEGIN

@interface BRMEntryDetailViewController : UIViewController

@property (weak, nonatomic) IBOutlet UITextField *titleTextField;
@property (weak, nonatomic) IBOutlet UITextField *dateTextField;
@property (weak, nonatomic) IBOutlet UITextView *bodyTextView;

@property (nonatomic, strong) BRMEntry *entry;

- (IBAction)saveButtonTapped:(UIBarButtonItem *)sender;
- (IBAction)clearButtonTapped:(UIButton *)sender;

@end

NS_ASSUME_NONNULL_END
