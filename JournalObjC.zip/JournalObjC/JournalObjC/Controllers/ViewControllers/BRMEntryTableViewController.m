//
//  BRMEntryTableViewController.m
//  JournalObjC
//
//  Created by Bethany Morris on 5/4/20.
//  Copyright © 2020 Bethany M. All rights reserved.
//

#import "BRMEntryTableViewController.h"
#import "BRMEntryController.h"
#import "BRMEntry.h"
#import "BRMEntryDetailViewController.h"

@interface BRMEntryTableViewController ()

@end

@implementation BRMEntryTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.tableView reloadData];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    [self.tableView reloadData];
}

#pragma mark - Table view data source

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return BRMEntryController.sharedInstance.entries.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"EntryCell" forIndexPath:indexPath];
    
    BRMEntry *entryCell = BRMEntryController.sharedInstance.entries[indexPath.row];
    cell.textLabel.text = entryCell.title;
    cell.detailTextLabel.text = entryCell.date;
    
    return cell;
}

// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        
        BRMEntry *entryToDelete = BRMEntryController.sharedInstance.entries[indexPath.row];
        [BRMEntryController.sharedInstance deleteEntry:entryToDelete];
        
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    }
}

#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // IIDOO
    if ([segue.identifier isEqualToString:@"ToEntryDetailVC"]) {
        NSIndexPath *indexPath = self.tableView.indexPathForSelectedRow;
        BRMEntryDetailViewController *destinationVC = (BRMEntryDetailViewController *)segue.destinationViewController;
        BRMEntry *entry = BRMEntryController.sharedInstance.entries[indexPath.row];
        destinationVC.entry = entry;
    }
}


@end
