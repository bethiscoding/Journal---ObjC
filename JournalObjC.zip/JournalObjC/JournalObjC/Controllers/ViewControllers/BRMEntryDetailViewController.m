//
//  BRMEntryDetailViewController.m
//  JournalObjC
//
//  Created by Bethany Morris on 5/4/20.
//  Copyright © 2020 Bethany M. All rights reserved.
//

#import "BRMEntryDetailViewController.h"
#import "BRMEntryController.h"

@interface BRMEntryDetailViewController ()

@end

@implementation BRMEntryDetailViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    [self updateViews];
}

// MARK: - Methods

- (void)updateViews
{
    if (!self.entry) return;
    
    _titleTextField.text = _entry.title;
    _dateTextField.text = _entry.date;
    _bodyTextView.text = _entry.bodyText;
}

- (IBAction)clearButtonTapped:(UIButton *)sender {
    _titleTextField.text = @"";
    _dateTextField.text = @"";
    _bodyTextView.text = @"";
}

- (IBAction)saveButtonTapped:(UIBarButtonItem *)sender {
    if (self.entry) {
        _entry.title = _titleTextField.text;
        _entry.date = _dateTextField.text;
        _entry.bodyText = _bodyTextView.text;
    } else {
        BRMEntry *entry = [[BRMEntry alloc] initWithTitle:_titleTextField.text date:_dateTextField.text bodyText:_bodyTextView.text];
        [[BRMEntryController sharedInstance] addEntry:entry];
        _entry = entry;
    }
        [self.navigationController popViewControllerAnimated:true];
    }

    #pragma mark - UITextFieldDelegate Methods

    - (BOOL)textFieldShouldReturn:(UITextField *)textField
    {
        [textField resignFirstResponder];
        return YES;
    }

    #pragma mark - Properties

    - (void)setEntry:(BRMEntry *)entry
    {
        if (entry != _entry) {
            _entry = entry;
            [self updateViews];
        }
    }

@end
