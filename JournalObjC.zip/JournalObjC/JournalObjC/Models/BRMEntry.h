//
//  BRMEntry.h
//  JournalObjC
//
//  Created by Bethany Morris on 5/4/20.
//  Copyright © 2020 Bethany M. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface BRMEntry : NSObject

@property (nonatomic, copy) NSString *title;
@property (nonatomic, copy) NSString *date;
@property (nonatomic, copy) NSString *bodyText;

- (instancetype) initWithTitle:(NSString *)title
                          date:(NSString *)date
                      bodyText:(NSString *)bodyText;

- (instancetype)initWithDictionary:(NSDictionary *)dictionary;
- (NSDictionary *)dictionaryRepresentation;

@end

NS_ASSUME_NONNULL_END
