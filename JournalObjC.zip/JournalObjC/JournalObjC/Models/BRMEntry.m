//
//  BRMEntry.m
//  JournalObjC
//
//  Created by Bethany Morris on 5/4/20.
//  Copyright © 2020 Bethany M. All rights reserved.
//

#import "BRMEntry.h"

static NSString * const TitleKey = @"title";
static NSString * const DateKey = @"date";
static NSString * const BodyTextKey = @"bodyText";

@implementation BRMEntry

- (instancetype)initWithTitle:(NSString *)title
                         date:(NSString *)date
                     bodyText:(NSString *)bodyText
{
    self = [super init];
    if (self) {
        _title = title;
        _date = date;
        _bodyText = bodyText;
    }
    return self;
}

- (instancetype)initWithDictionary:(NSDictionary *)dictionary
{
    NSString *title = dictionary[TitleKey];
    NSString *date = dictionary[DateKey];
    NSString *bodyText = dictionary[BodyTextKey];
    return [self initWithTitle:title date:date bodyText:bodyText];
}

- (NSDictionary *)dictionaryRepresentation
{
    return @{TitleKey: self.title,
             DateKey: self.date,
             BodyTextKey: self.bodyText};
}

- (BOOL)isEqual:(id)object
{
    if (![object isKindOfClass:[BRMEntry class]]) { return NO; }
    // Shortcut to comparing all properties one by one. We let NSDictionary do it for us
    return [[self dictionaryRepresentation] isEqualToDictionary:[(BRMEntry *)object dictionaryRepresentation]];
}

@end
